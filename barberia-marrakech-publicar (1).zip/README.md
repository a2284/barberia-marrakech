# Barbería Marrakech

Aplicación web estática de reservas para una barbería.

## Publicación

1. Sube `index.html` a un repositorio de GitHub.
2. En GitHub abre **Settings → Pages**.
3. En **Build and deployment**, selecciona **Deploy from a branch**.
4. Selecciona `main` y la carpeta `/root`.
5. Guarda y espera a que GitHub Pages publique el sitio.

## Funciones

- Reserva de Corte, Barba y Combo.
- Fecha y hora.
- Persistencia con localStorage.
- Confirmación de reserva.
- Panel de barbero.
- PIN predeterminado: `1234`.
- Agenda por fecha.
- Estados pendiente, completada y cancelada.
- Enlace directo a WhatsApp.
- Responsive y modo oscuro.

## Nota

`localStorage` guarda las citas únicamente en el navegador/dispositivo donde se crean. Para compartir una agenda entre varios dispositivos se necesita un backend/base de datos.
